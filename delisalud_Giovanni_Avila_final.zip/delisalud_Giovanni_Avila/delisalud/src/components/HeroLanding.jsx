import "../styles/Hero.css";

function HeroLanding() {
  return (
    <section className="hero">

      <div className="container py-5">

        <div className="row">

          <div className="col-lg-8">

            <h1 className="display-3 fw-bold">
              Alimentación saludable para una vida mejor
            </h1>

            <p className="fs-5 mt-3">
              En DeliSalud preparamos comidas saludables con ingredientes
              frescos y de calidad. Descubre nuestros menús diarios,
              diseñados para ofrecer una alimentación equilibrada y llena de
              sabor, con despacho directo hasta tu hogar.
            </p>

          </div>

        </div>

      </div>

    </section>
  );
}

export default HeroLanding;