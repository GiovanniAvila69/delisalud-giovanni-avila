import Hero from "../components/Hero";

function Login() {
  return (
    <main>
      <Hero />
    </main>
  );
}

export default Login;