"""Pruebas de la API real (HTTP + token + base de datos). Requieren Django instalado."""
from django.contrib.auth.models import User
from rest_framework.authtoken.models import Token
from rest_framework.test import APITestCase

# Mismo formato que construye el React (construirPayloadPedido en pedidosApi.js)
PEDIDO_REACT = {
    "cliente": "Camila Rojas", "email": "camila@correo.com", "telefono": "+56911112222",
    "direccion": "Los Aromos 45", "monto": 13980, "estado": "pendiente",
    "fecha": "2026-10-07", "metodoPago": "efectivo", "pagaCon": "20000", "tiempoEstimado": 25,
    "items": [{"producto": "Quinoa con pollo a la plancha", "cantidad": 2, "precio": 6990}],
}


class ApiTests(APITestCase):
    def setUp(self):
        user = User.objects.create_user("tester", password="clave12345")
        self.token = Token.objects.create(user=user)

    def auth(self):
        self.client.credentials(HTTP_AUTHORIZATION=f"Token {self.token.key}")

    def test_sin_token_401(self):
        self.assertEqual(self.client.get("/api/platos/").status_code, 401)
        self.assertEqual(self.client.get("/api/pedidos/").status_code, 401)
        self.assertEqual(self.client.post("/api/pedidos", PEDIDO_REACT, format="json").status_code, 401)

    def test_login_entrega_token(self):
        r = self.client.post("/api/login/", {"username": "tester", "password": "clave12345"}, format="json")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.data["token"], self.token.key)

    def test_catalogo_inicial_cargado(self):
        self.auth()
        nombres = [p["nombre"] for p in self.client.get("/api/platos/").data["datos"]]
        self.assertIn("Lentejas", nombres)
        self.assertIn("Fajitas de pollo", nombres)

    def test_crud_platos(self):
        self.auth()
        r = self.client.post("/api/platos/", {"nombre": "Bowl Test", "precio": 5000}, format="json")
        self.assertEqual(r.status_code, 201)
        pid = r.data["id"]
        self.assertEqual(r.data["_id"], pid)
        self.assertEqual(self.client.get(f"/api/platos/{pid}/").status_code, 200)
        r = self.client.put(f"/api/platos/{pid}/", {"nombre": "Bowl XL", "precio": 6000}, format="json")
        self.assertEqual(r.data["precio"], 6000)
        self.assertEqual(self.client.delete(f"/api/platos/{pid}/").status_code, 200)
        self.assertEqual(self.client.get(f"/api/platos/{pid}/").status_code, 404)

    def test_crud_pedidos_formato_react(self):
        self.auth()
        # URLs SIN barra final, como las usa el React
        r = self.client.post("/api/pedidos", PEDIDO_REACT, format="json")
        self.assertEqual(r.status_code, 201)
        self.assertEqual(r.data["monto"], 13980)
        self.assertEqual(r.data["cliente"], "Camila Rojas")
        self.assertEqual(r.data["metodoPago"], "efectivo")
        self.assertIsNotNone(r.data["plato_id"])
        oid = r.data["id"]

        lista = self.client.get("/api/pedidos").data["datos"]
        self.assertTrue(any(p["_id"] == oid for p in lista))
        self.assertEqual(self.client.get(f"/api/pedidos/{oid}").status_code, 200)

        # Edición como VerPedidos.jsx (manda todo el pedido de vuelta)
        edit = dict(self.client.get(f"/api/pedidos/{oid}").data)
        edit["cliente"] = "Camila R."
        r = self.client.put(f"/api/pedidos/{oid}", edit, format="json")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.data["cliente"], "Camila R.")

        # Cancelar como Home.jsx
        r = self.client.put(f"/api/pedidos/{oid}", {**PEDIDO_REACT, "estado": "cancelado"}, format="json")
        self.assertEqual(r.data["estado"], "cancelado")

        self.assertEqual(self.client.delete(f"/api/pedidos/{oid}").status_code, 200)
        self.assertEqual(self.client.get(f"/api/pedidos/{oid}").status_code, 404)

    def test_editar_pedido_como_EditarPedido_jsx(self):
        self.auth()
        oid = self.client.post("/api/pedidos", PEDIDO_REACT, format="json").data["id"]
        datos = {"nombre": "Camila Rojas", "pedido": "Lentejas", "cantidad": "3",
                 "precio": "5490", "telefono": "+56900000000", "direccion": "Calle Nueva 1",
                 "departamento": "12B", "referencia": "Portón negro"}
        r = self.client.put(f"/api/pedidos/{oid}", datos, format="json")
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.data["monto"], 16470)
        self.assertEqual(r.data["direccion"], "Calle Nueva 1")

    def test_producto_fuera_del_catalogo_400(self):
        self.auth()
        malo = {**PEDIDO_REACT, "items": [{"producto": "Pizza", "cantidad": 1, "precio": 9990}]}
        self.assertEqual(self.client.post("/api/pedidos", malo, format="json").status_code, 400)

    def test_cantidad_invalida_400(self):
        self.auth()
        malo = {**PEDIDO_REACT, "items": [{"producto": "Lentejas", "cantidad": 0, "precio": 5490}]}
        self.assertEqual(self.client.post("/api/pedidos", malo, format="json").status_code, 400)

    def test_pedido_inexistente_404(self):
        self.auth()
        self.assertEqual(self.client.get("/api/pedidos/99999").status_code, 404)
