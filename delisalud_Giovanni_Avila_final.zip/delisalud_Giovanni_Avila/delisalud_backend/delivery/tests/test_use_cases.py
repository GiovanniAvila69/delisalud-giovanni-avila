"""Prueba la lógica de negocio SIN Django ni base de datos (repositorios en memoria).
Esto demuestra el beneficio de la arquitectura hexagonal."""
import unittest

from delivery.application import use_cases as uc
from delivery.domain.entities import Pedido, Plato
from delivery.domain.exceptions import DomainError, NotFoundError
from delivery.domain.repositories import PedidoRepository, PlatoRepository


class MemRepo:
    def __init__(self):
        self.d, self.n = {}, 0

    def listar(self):
        return list(self.d.values())

    def obtener(self, id):
        return self.d.get(id)

    def crear(self, e):
        self.n += 1
        e.id = self.n
        self.d[e.id] = e
        return e

    def actualizar(self, id, e):
        if id not in self.d:
            return None
        e.id = id
        self.d[id] = e
        return e

    def eliminar(self, id):
        return self.d.pop(id, None) is not None


class MemPlatoRepo(MemRepo, PlatoRepository):
    pass


class MemPedidoRepo(MemRepo, PedidoRepository):
    pass


def pedido(**kw):
    base = dict(cliente_nombre="Ana", cliente_email="a@a.cl", cliente_direccion="Calle 1",
                items=[{"producto": "Lentejas", "cantidad": 1, "precio": 5490}])
    base.update(kw)
    return Pedido(**base)


class UseCaseTests(unittest.TestCase):
    def setUp(self):
        self.platos = MemPlatoRepo()
        self.pedidos = MemPedidoRepo()
        for nombre, precio in [("Lentejas", 5490), ("Quinoa con pollo a la plancha", 6990),
                               ("Salmón al horno con papas", 8990)]:
            uc.CrearPlato(self.platos).execute(Plato(nombre=nombre, precio=precio))
        self.crear = uc.CrearPedido(self.pedidos, self.platos)
        self.actualizar = uc.ActualizarPedido(self.pedidos, self.platos)

    # --- platos ---
    def test_plato_precio_invalido(self):
        with self.assertRaises(DomainError):
            uc.CrearPlato(self.platos).execute(Plato(nombre="X", precio=0))

    def test_plato_inexistente(self):
        with self.assertRaises(NotFoundError):
            uc.ObtenerPlato(self.platos).execute(99)

    # --- pedidos ---
    def test_total_y_plato_principal(self):
        p = pedido(items=[{"producto": "Quinoa con pollo a la plancha", "cantidad": 2, "precio": 6990},
                          {"producto": "Lentejas", "cantidad": 1, "precio": 5490}])
        creado = self.crear.execute(p)
        self.assertEqual(creado.total, 19470)
        self.assertEqual(creado.plato_id, 2)  # FK al primer producto
        self.assertIsNotNone(creado.fecha)
        self.assertEqual(creado.tiempo_estimado, 35)  # 3 unidades

    def test_nombre_con_emoji_y_sufijo(self):
        p = pedido(items=[{"producto": "🐟 Salmón al horno con papas cocidas", "cantidad": 1, "precio": 8990}])
        self.assertEqual(self.crear.execute(p).plato_id, 3)

    def test_nombre_con_emoji_lentejas(self):
        p = pedido(items=[{"producto": "🥣 Lentejas con verduras", "cantidad": 1, "precio": 5490}])
        self.assertEqual(self.crear.execute(p).plato_id, 1)

    def test_sin_precio_usa_catalogo(self):
        p = pedido(items=[{"producto": "Lentejas", "cantidad": 2}])
        self.assertEqual(self.crear.execute(p).total, 10980)

    def test_solo_plato_id(self):
        p = Pedido(cliente_nombre="Ana", cliente_direccion="Calle 1", plato_id=1)
        self.assertEqual(self.crear.execute(p).total, 5490)

    def test_producto_fuera_del_catalogo(self):
        p = pedido(items=[{"producto": "Pizza", "cantidad": 1, "precio": 100}])
        with self.assertRaises(DomainError):
            self.crear.execute(p)

    def test_plato_id_inexistente(self):
        with self.assertRaises(DomainError):
            self.crear.execute(pedido(plato_id=99))

    def test_sin_items_ni_plato(self):
        with self.assertRaises(DomainError):
            self.crear.execute(Pedido(cliente_nombre="Ana", cliente_direccion="Calle 1"))

    def test_cantidad_invalida(self):
        p = pedido(items=[{"producto": "Lentejas", "cantidad": 0, "precio": 5490}])
        with self.assertRaises(DomainError):
            self.crear.execute(p)

    def test_cliente_y_direccion_obligatorios(self):
        with self.assertRaises(DomainError):
            self.crear.execute(pedido(cliente_nombre="  "))
        with self.assertRaises(DomainError):
            self.crear.execute(pedido(cliente_direccion=""))

    def test_estado_y_pago_invalidos(self):
        with self.assertRaises(DomainError):
            self.crear.execute(pedido(estado="volando"))
        with self.assertRaises(DomainError):
            self.crear.execute(pedido(metodo_pago="bitcoin"))

    # --- actualizar ---
    def test_actualizar_parcial_mantiene_el_resto(self):
        creado = self.crear.execute(pedido())
        nuevo = self.actualizar.execute(creado.id, {"cliente_telefono": "+5691"})
        self.assertEqual(nuevo.cliente_telefono, "+5691")
        self.assertEqual(nuevo.cliente_nombre, "Ana")
        self.assertEqual(nuevo.total, 5490)

    def test_actualizar_items_recalcula(self):
        creado = self.crear.execute(pedido())
        nuevo = self.actualizar.execute(creado.id, {"items": [
            {"producto": "Salmón al horno con papas", "cantidad": 2, "precio": 8990}]})
        self.assertEqual(nuevo.total, 17980)
        self.assertEqual(nuevo.plato_id, 3)

    def test_cancelar_y_luego_no_modificar(self):
        creado = self.crear.execute(pedido())
        self.actualizar.execute(creado.id, {"estado": "cancelado"})
        with self.assertRaises(DomainError):
            self.actualizar.execute(creado.id, {"cliente_nombre": "Otra"})

    def test_actualizar_inexistente(self):
        with self.assertRaises(NotFoundError):
            self.actualizar.execute(123, {"estado": "cancelado"})

    def test_eliminar_inexistente(self):
        with self.assertRaises(NotFoundError):
            uc.EliminarPedido(self.pedidos).execute(123)


if __name__ == "__main__":
    unittest.main()
