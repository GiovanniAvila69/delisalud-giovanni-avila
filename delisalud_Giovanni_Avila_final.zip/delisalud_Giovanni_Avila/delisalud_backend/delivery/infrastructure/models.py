"""Modelos ORM de Django (tablas). Solo estructura de datos, sin reglas de negocio."""
from django.db import models


class PlatoModel(models.Model):
    nombre = models.CharField(max_length=150)
    descripcion = models.TextField(blank=True, default="")
    precio = models.PositiveIntegerField()
    categoria = models.CharField(max_length=80, blank=True, default="")
    calorias = models.PositiveIntegerField(default=0)
    imagen = models.CharField(max_length=500, blank=True, default="")
    disponible = models.BooleanField(default=True)

    class Meta:
        db_table = "delivery_platos"

    def __str__(self):
        return self.nombre


class PedidoModel(models.Model):
    # ForeignKey: equivalente relacional del "platoId" suelto de Mongo
    plato = models.ForeignKey(PlatoModel, on_delete=models.CASCADE, related_name="pedidos")
    # Subdocumento "cliente" aplanado en columnas
    cliente_nombre = models.CharField(max_length=150)
    cliente_email = models.CharField(max_length=150, blank=True, default="")
    cliente_telefono = models.CharField(max_length=30, blank=True, default="")
    cliente_direccion = models.CharField(max_length=250)
    departamento = models.CharField(max_length=100, blank=True, default="")
    referencia = models.TextField(blank=True, default="")
    # Array "items" -> un solo JSONField (sin crear 3ra entidad)
    items = models.JSONField(default=list, blank=True)
    total = models.PositiveIntegerField(default=0)
    estado = models.CharField(max_length=30, default="pendiente")
    metodo_pago = models.CharField(max_length=30, default="efectivo")
    paga_con = models.CharField(max_length=50, blank=True, default="")
    tiempo_estimado = models.PositiveIntegerField(null=True, blank=True)
    fecha = models.DateField()

    class Meta:
        db_table = "delivery_pedidos"

    def __str__(self):
        return f"Pedido {self.pk} - {self.cliente_nombre}"
