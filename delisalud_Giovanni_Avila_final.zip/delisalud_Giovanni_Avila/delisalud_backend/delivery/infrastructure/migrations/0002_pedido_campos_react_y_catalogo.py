from django.db import migrations, models

from delivery.infrastructure.catalogo_inicial import PLATOS


def cargar_catalogo(apps, schema_editor):
    Plato = apps.get_model("delivery", "PlatoModel")
    for datos in PLATOS:
        Plato.objects.get_or_create(nombre=datos["nombre"], defaults=datos)


class Migration(migrations.Migration):
    dependencies = [("delivery", "0001_initial")]

    operations = [
        migrations.AddField("pedidomodel", "cliente_telefono",
                            models.CharField(blank=True, default="", max_length=30)),
        migrations.AddField("pedidomodel", "departamento",
                            models.CharField(blank=True, default="", max_length=100)),
        migrations.AddField("pedidomodel", "referencia",
                            models.TextField(blank=True, default="")),
        migrations.AddField("pedidomodel", "metodo_pago",
                            models.CharField(default="efectivo", max_length=30)),
        migrations.AddField("pedidomodel", "paga_con",
                            models.CharField(blank=True, default="", max_length=50)),
        migrations.AddField("pedidomodel", "tiempo_estimado",
                            models.PositiveIntegerField(blank=True, null=True)),
        migrations.RunPython(cargar_catalogo, migrations.RunPython.noop),
    ]
