import django.db.models.deletion
from django.db import migrations, models


class Migration(migrations.Migration):
    initial = True
    dependencies = []

    operations = [
        migrations.CreateModel(
            name="PlatoModel",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("nombre", models.CharField(max_length=150)),
                ("descripcion", models.TextField(blank=True, default="")),
                ("precio", models.PositiveIntegerField()),
                ("categoria", models.CharField(blank=True, default="", max_length=80)),
                ("calorias", models.PositiveIntegerField(default=0)),
                ("imagen", models.CharField(blank=True, default="", max_length=500)),
                ("disponible", models.BooleanField(default=True)),
            ],
            options={"db_table": "delivery_platos"},
        ),
        migrations.CreateModel(
            name="PedidoModel",
            fields=[
                ("id", models.BigAutoField(auto_created=True, primary_key=True, serialize=False, verbose_name="ID")),
                ("cliente_nombre", models.CharField(max_length=150)),
                ("cliente_email", models.CharField(blank=True, default="", max_length=150)),
                ("cliente_direccion", models.CharField(max_length=250)),
                ("items", models.JSONField(blank=True, default=list)),
                ("total", models.PositiveIntegerField(default=0)),
                ("estado", models.CharField(default="pendiente", max_length=30)),
                ("fecha", models.DateField()),
                ("plato", models.ForeignKey(on_delete=django.db.models.deletion.CASCADE, related_name="pedidos", to="delivery.platomodel")),
            ],
            options={"db_table": "delivery_pedidos"},
        ),
    ]
