"""Implementación concreta (adaptador) de los repositorios usando el ORM de Django."""
from typing import List, Optional

from ..domain.entities import Pedido, Plato
from ..domain.repositories import PedidoRepository, PlatoRepository
from .models import PedidoModel, PlatoModel


class DjangoPlatoRepository(PlatoRepository):
    @staticmethod
    def _to_entity(m: PlatoModel) -> Plato:
        return Plato(
            id=m.id, nombre=m.nombre, descripcion=m.descripcion, precio=m.precio,
            categoria=m.categoria, calorias=m.calorias, imagen=m.imagen,
            disponible=m.disponible,
        )

    @staticmethod
    def _fields(p: Plato) -> dict:
        return dict(
            nombre=p.nombre, descripcion=p.descripcion, precio=p.precio,
            categoria=p.categoria, calorias=p.calorias, imagen=p.imagen,
            disponible=p.disponible,
        )

    def listar(self) -> List[Plato]:
        return [self._to_entity(m) for m in PlatoModel.objects.all().order_by("id")]

    def obtener(self, id: int) -> Optional[Plato]:
        m = PlatoModel.objects.filter(pk=id).first()
        return self._to_entity(m) if m else None

    def crear(self, plato: Plato) -> Plato:
        return self._to_entity(PlatoModel.objects.create(**self._fields(plato)))

    def actualizar(self, id: int, plato: Plato) -> Optional[Plato]:
        m = PlatoModel.objects.filter(pk=id).first()
        if not m:
            return None
        for campo, valor in self._fields(plato).items():
            setattr(m, campo, valor)
        m.save()
        return self._to_entity(m)

    def eliminar(self, id: int) -> bool:
        borrados, _ = PlatoModel.objects.filter(pk=id).delete()
        return borrados > 0


class DjangoPedidoRepository(PedidoRepository):
    @staticmethod
    def _to_entity(m: PedidoModel) -> Pedido:
        return Pedido(
            id=m.id, plato_id=m.plato_id, cliente_nombre=m.cliente_nombre,
            cliente_email=m.cliente_email, cliente_telefono=m.cliente_telefono,
            cliente_direccion=m.cliente_direccion, departamento=m.departamento,
            referencia=m.referencia, items=m.items, total=m.total, estado=m.estado,
            metodo_pago=m.metodo_pago, paga_con=m.paga_con,
            tiempo_estimado=m.tiempo_estimado, fecha=m.fecha,
        )

    @staticmethod
    def _fields(p: Pedido) -> dict:
        return dict(
            plato_id=p.plato_id, cliente_nombre=p.cliente_nombre,
            cliente_email=p.cliente_email, cliente_telefono=p.cliente_telefono,
            cliente_direccion=p.cliente_direccion, departamento=p.departamento,
            referencia=p.referencia, items=p.items, total=p.total, estado=p.estado,
            metodo_pago=p.metodo_pago, paga_con=p.paga_con,
            tiempo_estimado=p.tiempo_estimado, fecha=p.fecha,
        )

    def listar(self) -> List[Pedido]:
        return [self._to_entity(m) for m in PedidoModel.objects.all().order_by("-id")]

    def obtener(self, id: int) -> Optional[Pedido]:
        m = PedidoModel.objects.filter(pk=id).first()
        return self._to_entity(m) if m else None

    def crear(self, pedido: Pedido) -> Pedido:
        return self._to_entity(PedidoModel.objects.create(**self._fields(pedido)))

    def actualizar(self, id: int, pedido: Pedido) -> Optional[Pedido]:
        m = PedidoModel.objects.filter(pk=id).first()
        if not m:
            return None
        for campo, valor in self._fields(pedido).items():
            setattr(m, campo, valor)
        m.save()
        return self._to_entity(m)

    def eliminar(self, id: int) -> bool:
        borrados, _ = PedidoModel.objects.filter(pk=id).delete()
        return borrados > 0
