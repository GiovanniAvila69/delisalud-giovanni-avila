from django.urls import path, re_path
from rest_framework.authtoken.views import obtain_auth_token

from .views import (
    PedidoDetailView, PedidoListCreateView,
    PlatoDetailView, PlatoListCreateView,
)

# La barra final es opcional (/api/pedidos y /api/pedidos/ funcionan), porque el
# React llama a las URLs sin barra final.
urlpatterns = [
    path("login/", obtain_auth_token),  # POST {username, password} -> {token}
    re_path(r"^platos/?$", PlatoListCreateView.as_view()),
    re_path(r"^platos/(?P<id>\d+)/?$", PlatoDetailView.as_view()),
    re_path(r"^pedidos/?$", PedidoListCreateView.as_view()),
    re_path(r"^pedidos/(?P<id>\d+)/?$", PedidoDetailView.as_view()),
]
