"""Serializers: traducen entre el JSON que usa el React y las entidades del dominio."""
import re

from rest_framework import serializers


def _entero(valor, defecto=0):
    """'$5.990' -> 5990 ; '' -> defecto"""
    digitos = re.sub(r"\D", "", str(valor if valor is not None else ""))
    return int(digitos) if digitos else defecto


class PlatoSerializer(serializers.Serializer):
    id = serializers.IntegerField(read_only=True)
    nombre = serializers.CharField(max_length=150)
    descripcion = serializers.CharField(required=False, allow_blank=True, default="")
    precio = serializers.IntegerField(min_value=0)
    categoria = serializers.CharField(required=False, allow_blank=True, default="")
    calorias = serializers.IntegerField(required=False, min_value=0, default=0)
    imagen = serializers.CharField(required=False, allow_blank=True, default="")
    disponible = serializers.BooleanField(required=False, default=True)

    def to_representation(self, instance):
        data = super().to_representation(instance)
        data["_id"] = data.get("id")  # compatibilidad con el React hecho para Mongo
        return data


class PedidoSerializer(serializers.Serializer):
    """Entrada y salida con los mismos nombres que ya usa el React (pedidosApi.js)."""

    # --- entrada (todo opcional aquí; las reglas de negocio las valida el caso de uso) ---
    cliente = serializers.CharField(required=False, allow_blank=True)
    nombre = serializers.CharField(required=False, allow_blank=True)  # usado por EditarPedido.jsx
    email = serializers.CharField(required=False, allow_blank=True)
    telefono = serializers.CharField(required=False, allow_blank=True)
    direccion = serializers.CharField(required=False, allow_blank=True)
    departamento = serializers.CharField(required=False, allow_blank=True)
    referencia = serializers.CharField(required=False, allow_blank=True)
    estado = serializers.CharField(required=False)
    metodoPago = serializers.CharField(required=False, allow_blank=True)
    pagaCon = serializers.CharField(required=False, allow_blank=True, allow_null=True)
    tiempoEstimado = serializers.IntegerField(required=False, allow_null=True)
    items = serializers.ListField(child=serializers.DictField(), required=False)
    plato_id = serializers.IntegerField(required=False, allow_null=True)
    # EditarPedido.jsx manda un solo producto con estos campos
    pedido = serializers.CharField(required=False, allow_blank=True)
    cantidad = serializers.CharField(required=False, allow_blank=True)
    precio = serializers.CharField(required=False, allow_blank=True)
    # "monto" y "fecha" que manda el React se ignoran: los calcula el servidor

    def a_cambios(self) -> dict:
        """Convierte los datos validados a campos de la entidad Pedido."""
        d = self.validated_data
        cambios = {}
        nombre = d.get("cliente", d.get("nombre"))
        if nombre is not None:
            cambios["cliente_nombre"] = nombre
        mapa = {
            "email": "cliente_email", "telefono": "cliente_telefono",
            "direccion": "cliente_direccion", "departamento": "departamento",
            "referencia": "referencia", "estado": "estado", "metodoPago": "metodo_pago",
            "tiempoEstimado": "tiempo_estimado", "plato_id": "plato_id", "items": "items",
        }
        for origen, destino in mapa.items():
            if origen in d:
                cambios[destino] = d[origen]
        if "pagaCon" in d:
            cambios["paga_con"] = d["pagaCon"] or ""
        if "items" not in d and d.get("pedido"):
            cambios["items"] = [{
                "producto": d["pedido"],
                "cantidad": _entero(d.get("cantidad"), 1),
                "precio": _entero(d.get("precio"), 0),
            }]
        return cambios

    def to_representation(self, p):
        return {
            "id": p.id, "_id": p.id, "plato_id": p.plato_id,
            "cliente": p.cliente_nombre, "email": p.cliente_email,
            "telefono": p.cliente_telefono, "direccion": p.cliente_direccion,
            "departamento": p.departamento, "referencia": p.referencia,
            "monto": p.total, "total": p.total, "estado": p.estado,
            "fecha": p.fecha.isoformat() if p.fecha else None,
            "metodoPago": p.metodo_pago, "pagaCon": p.paga_con,
            "tiempoEstimado": p.tiempo_estimado, "items": p.items,
        }
