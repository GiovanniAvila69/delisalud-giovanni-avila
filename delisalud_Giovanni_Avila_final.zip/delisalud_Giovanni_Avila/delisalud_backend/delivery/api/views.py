"""Vistas delgadas: reciben HTTP, llaman al caso de uso y devuelven la respuesta."""
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView

from ..application import use_cases as uc
from ..domain.entities import Pedido, Plato
from ..domain.exceptions import DomainError, NotFoundError
from ..infrastructure.repositories import DjangoPedidoRepository, DjangoPlatoRepository
from .serializers import PedidoSerializer, PlatoSerializer

# Inyección de dependencias: aquí se "enchufa" la implementación Django al dominio
plato_repo = DjangoPlatoRepository()
pedido_repo = DjangoPedidoRepository()


def _error(exc):
    if isinstance(exc, NotFoundError):
        return Response({"error": str(exc)}, status=status.HTTP_404_NOT_FOUND)
    return Response({"error": str(exc)}, status=status.HTTP_400_BAD_REQUEST)


# ------------------------------ PLATOS ------------------------------
class PlatoListCreateView(APIView):
    def get(self, request):
        platos = uc.ListarPlatos(plato_repo).execute()
        # Mismo formato que la API anterior: { "datos": [...] }
        return Response({"datos": PlatoSerializer(platos, many=True).data})

    def post(self, request):
        s = PlatoSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        try:
            creado = uc.CrearPlato(plato_repo).execute(Plato(**s.validated_data))
        except (DomainError, NotFoundError) as e:
            return _error(e)
        return Response(PlatoSerializer(creado).data, status=status.HTTP_201_CREATED)


class PlatoDetailView(APIView):
    def get(self, request, id):
        try:
            plato = uc.ObtenerPlato(plato_repo).execute(id)
        except (DomainError, NotFoundError) as e:
            return _error(e)
        return Response(PlatoSerializer(plato).data)

    def put(self, request, id):
        s = PlatoSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        try:
            plato = uc.ActualizarPlato(plato_repo).execute(id, Plato(**s.validated_data))
        except (DomainError, NotFoundError) as e:
            return _error(e)
        return Response(PlatoSerializer(plato).data)

    def delete(self, request, id):
        try:
            uc.EliminarPlato(plato_repo).execute(id)
        except (DomainError, NotFoundError) as e:
            return _error(e)
        return Response({"mensaje": "Plato eliminado"}, status=status.HTTP_200_OK)


# ------------------------------ PEDIDOS ------------------------------
class PedidoListCreateView(APIView):
    def get(self, request):
        pedidos = uc.ListarPedidos(pedido_repo).execute()
        return Response({"datos": PedidoSerializer(pedidos, many=True).data})

    def post(self, request):
        s = PedidoSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        try:
            creado = uc.CrearPedido(pedido_repo, plato_repo).execute(Pedido(**s.a_cambios()))
        except (DomainError, NotFoundError) as e:
            return _error(e)
        return Response(PedidoSerializer(creado).data, status=status.HTTP_201_CREATED)


class PedidoDetailView(APIView):
    def get(self, request, id):
        try:
            pedido = uc.ObtenerPedido(pedido_repo).execute(id)
        except (DomainError, NotFoundError) as e:
            return _error(e)
        return Response(PedidoSerializer(pedido).data)

    def put(self, request, id):
        s = PedidoSerializer(data=request.data)
        s.is_valid(raise_exception=True)
        try:
            pedido = uc.ActualizarPedido(pedido_repo, plato_repo).execute(id, s.a_cambios())
        except (DomainError, NotFoundError) as e:
            return _error(e)
        return Response(PedidoSerializer(pedido).data)

    def delete(self, request, id):
        try:
            uc.EliminarPedido(pedido_repo).execute(id)
        except (DomainError, NotFoundError) as e:
            return _error(e)
        return Response({"mensaje": "Pedido eliminado"}, status=status.HTTP_200_OK)
