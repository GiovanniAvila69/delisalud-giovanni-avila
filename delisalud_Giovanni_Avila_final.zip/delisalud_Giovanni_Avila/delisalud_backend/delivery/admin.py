from django.contrib import admin
from .infrastructure.models import PedidoModel, PlatoModel

admin.site.register(PlatoModel)
admin.site.register(PedidoModel)
