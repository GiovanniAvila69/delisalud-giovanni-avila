# Django busca los modelos aquí. Los modelos reales viven en infrastructure/models.py
from .infrastructure.models import PlatoModel, PedidoModel  # noqa: F401
