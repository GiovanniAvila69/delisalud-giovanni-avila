class DomainError(Exception):
    """Regla de negocio violada (se traduce a HTTP 400)."""


class NotFoundError(Exception):
    """Entidad no encontrada (se traduce a HTTP 404)."""
