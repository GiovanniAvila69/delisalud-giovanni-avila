"""Contratos (puertos) de los repositorios. Solo definen QUÉ se puede hacer."""
from abc import ABC, abstractmethod
from typing import List, Optional

from .entities import Pedido, Plato


class PlatoRepository(ABC):
    @abstractmethod
    def listar(self) -> List[Plato]: ...

    @abstractmethod
    def obtener(self, id: int) -> Optional[Plato]: ...

    @abstractmethod
    def crear(self, plato: Plato) -> Plato: ...

    @abstractmethod
    def actualizar(self, id: int, plato: Plato) -> Optional[Plato]: ...

    @abstractmethod
    def eliminar(self, id: int) -> bool: ...


class PedidoRepository(ABC):
    @abstractmethod
    def listar(self) -> List[Pedido]: ...

    @abstractmethod
    def obtener(self, id: int) -> Optional[Pedido]: ...

    @abstractmethod
    def crear(self, pedido: Pedido) -> Pedido: ...

    @abstractmethod
    def actualizar(self, id: int, pedido: Pedido) -> Optional[Pedido]: ...

    @abstractmethod
    def eliminar(self, id: int) -> bool: ...
