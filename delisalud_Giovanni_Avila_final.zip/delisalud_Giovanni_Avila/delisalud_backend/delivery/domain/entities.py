"""Entidades puras: NO importan nada de Django."""
from dataclasses import dataclass, field
from datetime import date
from typing import List, Optional

ESTADOS_PEDIDO = ("pendiente", "en_preparacion", "en_camino", "entregado", "cancelado")
METODOS_PAGO = ("efectivo", "tarjeta")


@dataclass
class Plato:
    nombre: str
    precio: int
    descripcion: str = ""
    categoria: str = ""
    calorias: int = 0
    imagen: str = ""
    disponible: bool = True
    id: Optional[int] = None


@dataclass
class Pedido:
    # Subdocumento "cliente" aplanado en columnas
    cliente_nombre: str = ""
    cliente_email: str = ""
    cliente_telefono: str = ""
    cliente_direccion: str = ""
    departamento: str = ""
    referencia: str = ""
    # [{"producto": "Lentejas", "cantidad": 2, "precio": 5490}, ...]
    items: List[dict] = field(default_factory=list)
    plato_id: Optional[int] = None  # plato principal (FK); se resuelve desde los items
    total: int = 0
    estado: str = "pendiente"
    metodo_pago: str = "efectivo"
    paga_con: str = ""
    tiempo_estimado: Optional[int] = None
    fecha: Optional[date] = None
    id: Optional[int] = None
