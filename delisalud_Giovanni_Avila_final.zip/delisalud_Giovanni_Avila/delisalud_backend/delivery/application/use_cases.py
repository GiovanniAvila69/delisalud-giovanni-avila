"""Casos de uso: aquí vive la lógica de negocio. No conocen Django ni HTTP."""
import re
import unicodedata
from dataclasses import replace
from datetime import date

from ..domain.entities import ESTADOS_PEDIDO, METODOS_PAGO, Pedido, Plato
from ..domain.exceptions import DomainError, NotFoundError
from ..domain.repositories import PedidoRepository, PlatoRepository


# ---------------------------- PLATOS ----------------------------
def _validar_plato(plato: Plato):
    if not plato.nombre or not plato.nombre.strip():
        raise DomainError("El nombre del plato es obligatorio.")
    if plato.precio is None or plato.precio <= 0:
        raise DomainError("El precio debe ser mayor a 0.")
    if plato.calorias is not None and plato.calorias < 0:
        raise DomainError("Las calorías no pueden ser negativas.")


class ListarPlatos:
    def __init__(self, repo: PlatoRepository):
        self.repo = repo

    def execute(self):
        return self.repo.listar()


class ObtenerPlato:
    def __init__(self, repo: PlatoRepository):
        self.repo = repo

    def execute(self, id: int):
        plato = self.repo.obtener(id)
        if plato is None:
            raise NotFoundError("Plato no encontrado.")
        return plato


class CrearPlato:
    def __init__(self, repo: PlatoRepository):
        self.repo = repo

    def execute(self, plato: Plato):
        _validar_plato(plato)
        return self.repo.crear(plato)


class ActualizarPlato:
    def __init__(self, repo: PlatoRepository):
        self.repo = repo

    def execute(self, id: int, plato: Plato):
        _validar_plato(plato)
        actualizado = self.repo.actualizar(id, plato)
        if actualizado is None:
            raise NotFoundError("Plato no encontrado.")
        return actualizado


class EliminarPlato:
    def __init__(self, repo: PlatoRepository):
        self.repo = repo

    def execute(self, id: int):
        if not self.repo.eliminar(id):
            raise NotFoundError("Plato no encontrado.")


# ---------------------------- PEDIDOS ----------------------------
def normalizar(texto) -> str:
    """'🥗 Salmón al Horno' -> 'salmon al horno' (sin emojis, tildes ni mayúsculas)."""
    texto = unicodedata.normalize("NFD", str(texto or ""))
    texto = "".join(c for c in texto if unicodedata.category(c) != "Mn")
    texto = re.sub(r"[^a-z0-9 ]", "", texto.lower())
    return " ".join(texto.split())


def buscar_plato_por_nombre(nombre, platos):
    """Busca el plato del catálogo que corresponde al nombre de un item del pedido."""
    buscado = normalizar(nombre)
    if not buscado:
        return None
    candidatos = []
    for plato in platos:
        n = normalizar(plato.nombre)
        if n and (n == buscado or n in buscado or buscado in n):
            candidatos.append((n == buscado, len(n), plato))
    if not candidatos:
        return None
    candidatos.sort(key=lambda c: (c[0], c[1]), reverse=True)
    return candidatos[0][2]


def _completar_pedido(pedido: Pedido, plato_repo: PlatoRepository):
    """Valida las reglas de negocio y calcula total, plato principal y tiempo estimado."""
    if not pedido.cliente_nombre.strip():
        raise DomainError("El nombre del cliente es obligatorio.")
    if not pedido.cliente_direccion.strip():
        raise DomainError("La dirección de entrega es obligatoria.")
    if pedido.estado not in ESTADOS_PEDIDO:
        raise DomainError(f"Estado inválido. Use uno de: {', '.join(ESTADOS_PEDIDO)}.")

    pedido.metodo_pago = (pedido.metodo_pago or "efectivo").strip().lower()
    if pedido.metodo_pago not in METODOS_PAGO:
        raise DomainError(f"Método de pago inválido. Use uno de: {', '.join(METODOS_PAGO)}.")

    platos = plato_repo.listar()
    por_id = {p.id: p for p in platos}

    if pedido.plato_id is not None and pedido.plato_id not in por_id:
        raise DomainError("El plato indicado no existe.")

    # Sin items: se pide 1 unidad del plato principal
    if not pedido.items:
        if pedido.plato_id is None:
            raise DomainError("El pedido debe tener al menos un producto.")
        plato = por_id[pedido.plato_id]
        pedido.items = [{"producto": plato.nombre, "cantidad": 1, "precio": plato.precio}]

    items_ok, total, cantidad_total = [], 0, 0
    for item in pedido.items:
        nombre = item.get("producto") or item.get("nombre")
        plato = buscar_plato_por_nombre(nombre, platos)
        if plato is None:
            raise DomainError(f"El producto '{nombre}' no existe en el catálogo.")
        if not plato.disponible:
            raise DomainError(f"El plato '{plato.nombre}' no está disponible.")

        cantidad = item.get("cantidad", 1)
        if isinstance(cantidad, bool) or not isinstance(cantidad, int) or cantidad <= 0:
            raise DomainError("Cada item debe tener una cantidad entera mayor a 0.")

        precio = item.get("precio")
        if precio is None or precio == 0:
            precio = plato.precio  # sin precio: se usa el del catálogo
        if isinstance(precio, bool) or not isinstance(precio, (int, float)) or precio < 0:
            raise DomainError("El precio de cada item debe ser un número mayor a 0.")

        items_ok.append({"producto": nombre, "cantidad": cantidad,
                         "precio": int(precio), "platoId": plato.id})
        total += int(precio) * cantidad
        cantidad_total += cantidad
        if pedido.plato_id is None:
            pedido.plato_id = plato.id

    pedido.items = items_ok
    pedido.total = total
    if pedido.tiempo_estimado is None:
        pedido.tiempo_estimado = 25 if cantidad_total <= 2 else 35 if cantidad_total <= 4 else 45


class ListarPedidos:
    def __init__(self, repo: PedidoRepository):
        self.repo = repo

    def execute(self):
        return self.repo.listar()


class ObtenerPedido:
    def __init__(self, repo: PedidoRepository):
        self.repo = repo

    def execute(self, id: int):
        pedido = self.repo.obtener(id)
        if pedido is None:
            raise NotFoundError("Pedido no encontrado.")
        return pedido


class CrearPedido:
    def __init__(self, repo: PedidoRepository, plato_repo: PlatoRepository):
        self.repo = repo
        self.plato_repo = plato_repo

    def execute(self, pedido: Pedido):
        _completar_pedido(pedido, self.plato_repo)
        pedido.fecha = date.today()
        return self.repo.crear(pedido)


class ActualizarPedido:
    """Recibe SOLO los campos a cambiar (dict) y los mezcla con el pedido existente."""

    def __init__(self, repo: PedidoRepository, plato_repo: PlatoRepository):
        self.repo = repo
        self.plato_repo = plato_repo

    def execute(self, id: int, cambios: dict):
        actual = self.repo.obtener(id)
        if actual is None:
            raise NotFoundError("Pedido no encontrado.")
        if actual.estado in ("entregado", "cancelado"):
            raise DomainError(f"No se puede modificar un pedido {actual.estado}.")

        nuevo = replace(actual, **cambios)
        if "items" in cambios and "plato_id" not in cambios:
            nuevo.plato_id = None  # se vuelve a resolver desde los nuevos items
            nuevo.tiempo_estimado = cambios.get("tiempo_estimado")
        nuevo.fecha = actual.fecha
        _completar_pedido(nuevo, self.plato_repo)
        return self.repo.actualizar(id, nuevo)


class EliminarPedido:
    def __init__(self, repo: PedidoRepository):
        self.repo = repo

    def execute(self, id: int):
        if not self.repo.eliminar(id):
            raise NotFoundError("Pedido no encontrado.")
