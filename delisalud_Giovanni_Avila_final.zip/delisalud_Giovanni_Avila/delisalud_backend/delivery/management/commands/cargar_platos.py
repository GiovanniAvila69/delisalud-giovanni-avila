from django.core.management.base import BaseCommand

from delivery.infrastructure.catalogo_inicial import PLATOS
from delivery.infrastructure.models import PlatoModel


class Command(BaseCommand):
    help = "Carga (o recarga) el catálogo de platos de DeliSalud"

    def handle(self, *args, **options):
        for datos in PLATOS:
            PlatoModel.objects.get_or_create(nombre=datos["nombre"], defaults=datos)
        self.stdout.write(self.style.SUCCESS("Catálogo de platos cargado."))
