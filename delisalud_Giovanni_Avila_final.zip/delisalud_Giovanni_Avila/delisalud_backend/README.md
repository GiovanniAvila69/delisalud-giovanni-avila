# DeliSalud — Back End Django (Arquitectura Hexagonal)

Entidades: **Plato** (principal, el catálogo) y **Pedido** (secundaria, con ForeignKey a Plato
y los productos del carrito en un `JSONField` llamado `items`).

## Estructura
```
config/                 settings, urls
delivery/
  domain/               entidades puras + contrato de repositorio (sin Django)
  application/          casos de uso (lógica de negocio)
  infrastructure/       modelos ORM + implementación del repositorio + migraciones
  api/                  serializers, views.py, urls.py
```

## Levantar el Back End (Python 3.10 o superior)
```bash
cd delisalud_backend
python -m pip install -r requirements.txt
python manage.py migrate            # crea las tablas y carga el catálogo de 8 platos
python manage.py createsuperuser
python manage.py drf_create_token <usuario>      # imprime el token
python manage.py runserver
```
Queda en http://127.0.0.1:8000/api/  (si hace falta recargar el catálogo: `python manage.py cargar_platos`).

Toda la API exige el header `Authorization: Token <token>`.
También se puede obtener con `POST /api/login/` enviando `{"username": "...", "password": "..."}`.

## Levantar el Front End (React)
```bash
cd delisalud
# editar .env y pegar el token:  VITE_API_TOKEN=<token>
pnpm install        # o: npm install
pnpm dev            # o: npm run dev
```
El React mantiene su estructura. Solo cambió `src/services/pedidosApi.js`: ahora apunta a
`http://127.0.0.1:8000/api/pedidos` y envía el token en cada petición. Los datos (URL y token) se
configuran en `delisalud/.env`.

## Endpoints
| Método | URL | Qué hace |
|---|---|---|
| POST | /api/login/ | Entrega el token (único endpoint público) |
| GET | /api/platos/ | Lista los platos (`{"datos": [...]}`) |
| POST | /api/platos/ | Crea un plato |
| GET | /api/platos/{id} | Detalle de un plato |
| PUT | /api/platos/{id} | Actualiza un plato |
| DELETE | /api/platos/{id} | Elimina un plato |
| GET | /api/pedidos/ | Lista los pedidos (`{"datos": [...]}`) |
| POST | /api/pedidos/ | Crea un pedido (calcula total, plato principal y tiempo estimado) |
| GET | /api/pedidos/{id} | Detalle de un pedido |
| PUT | /api/pedidos/{id} | Actualiza un pedido (basta con enviar los campos que cambian) |
| DELETE | /api/pedidos/{id} | Elimina un pedido |

La barra final es opcional (`/api/pedidos` y `/api/pedidos/` funcionan igual).

### Ejemplo de pedido (POST /api/pedidos) — mismo formato que envía el React
```json
{
  "cliente": "Camila Rojas",
  "email": "camila@correo.com",
  "telefono": "+56911112222",
  "direccion": "Los Aromos 45",
  "metodoPago": "efectivo",
  "pagaCon": "20000",
  "items": [{"producto": "Quinoa con pollo a la plancha", "cantidad": 2, "precio": 6990}]
}
```
Respuesta 201: el pedido con `id`, `monto` (13980), `plato_id`, `estado`, `fecha`, `tiempoEstimado`, etc.

## Reglas de negocio (capa application)
- Cliente y dirección obligatorios.
- Cada producto debe existir en el catálogo y estar disponible; cantidad entera > 0.
- El total lo calcula el servidor; el plato principal (ForeignKey) es el primer producto.
- Estados válidos: pendiente, en_preparacion, en_camino, entregado, cancelado.
- Pago: efectivo o tarjeta.
- No se modifica un pedido entregado o cancelado.

## Pruebas automáticas
```bash
python manage.py test
```
Incluye pruebas de la lógica de negocio (sin base de datos) y de la API completa (token, CRUD, errores).

## Del modelo Mongo al modelo relacional
- Colección principal → tabla `delivery_platos` (Plato). Colección secundaria → tabla `delivery_pedidos` (Pedido).
- `platoId` suelto → ForeignKey `plato`.
- Subdocumento `cliente` → columnas `cliente_nombre`, `cliente_email`, `cliente_telefono`, `cliente_direccion`.
- Array `items` → un solo campo JSON (sin crear una tercera entidad).
